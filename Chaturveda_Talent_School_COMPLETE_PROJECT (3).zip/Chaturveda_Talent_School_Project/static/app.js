function updateCasteOptions(){
  const religion=document.getElementById('religion');
  const caste=document.getElementById('caste');
  if(!religion||!caste)return;
  const data=window.CASTE_DATA||{};
  const selected=window.SELECTED_CASTE||'';
  caste.innerHTML='<option value="">Select Caste</option>';
  Object.keys(data[religion.value]||{}).forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v;if(v===selected)o.selected=true;caste.appendChild(o);});
  updateSubcasteOptions();
}
function updateSubcasteOptions(){
  const religion=document.getElementById('religion'), caste=document.getElementById('caste'), sub=document.getElementById('subcaste');
  if(!religion||!caste||!sub)return;
  const selected=window.SELECTED_SUBCASTE||'';
  sub.innerHTML='<option value="">Select Subcaste</option>';
  ((window.CASTE_DATA||{})[religion.value]||{})[caste.value]?.forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v;if(v===selected)o.selected=true;sub.appendChild(o);});
  window.SELECTED_SUBCASTE='';
}
function autoHideFlashes(){setTimeout(()=>document.querySelectorAll('.flash').forEach(x=>x.style.opacity='0'),6000);}
document.addEventListener('DOMContentLoaded',autoHideFlashes);

