# Thorough review of the original uploaded HTML application

The original file was a 1,644-line single HTML/CSS/JavaScript application. Its JavaScript is syntactically valid, but several design and data-integrity limitations make it unsuitable as the long-term school database.

## Problems found

1. **Browser localStorage is the only database.** Student and payment records live in the browser profile, not a central database. Closing the browser usually keeps them, but clearing site data, changing browser/profile/device, private browsing, or browser storage failure can remove access.
2. **No login or authorization.** Anyone who opens the page can view, edit, delete and clear records.
3. **The Clear All Stored Data button is dangerous.** It calls `localStorage.clear()` and `sessionStorage.clear()`, which clears all storage for the origin, not only the school's two keys.
4. **Payment history is not authoritative.** During student editing, `schoolPaid` and `vehiclePaid` can be directly changed without creating a payment transaction. This can make the displayed paid amount disagree with payment history.
5. **Receipt numbering is based on array length.** Deleting records can make a later receipt number collide with an older number. The new system uses a database payment ID.
6. **Student IDs use `Date.now()`.** This is not a reliable database identifier for a multi-user application.
7. **No multi-user support.** Two office computers cannot safely share the same browser-local data.
8. **No database transaction/rollback.** Browser writes can fail or become inconsistent if storage is unavailable or quota is reached.
9. **No attendance module.**
10. **No Excel/PDF reporting.**
11. **No notification provider integration.**
12. **No user/admin dashboards or user management.**
13. **No backup mechanism.**
14. **No server-side validation.** Client-side JavaScript validation can be bypassed by editing the page or storage.
15. **Search can fail on older/incomplete records.** Expressions such as `student.father.toLowerCase()` and `student.phone.includes()` assume those values always exist.
16. **Academic-year calculation is off by one in inclusive class ranges.** It calculates `endYear = startYear + yearsStudied`; an inclusive one-year study period should end in the same year.
17. **The currency number-to-words converter does not correctly handle Indian crore grouping.** The first two-digit group is labeled as lakh, so larger values can be wrong.
18. **Initial registration payments are forced to Cash.** The registration form has no payment method for the initial payment in the original code.
19. **No structured payment audit trail.** There is no authenticated user recorded against each payment.
20. **Deleting a student also deletes all payment history from localStorage.** This is undesirable for financial records. The replacement archives students instead.
21. **Certificates use hard-coded school/principal details.** The replacement centralizes school configuration in `app.py`.
22. **Large table UI becomes very wide.** The replacement uses focused student pages and a cleaner report layout.
23. **No permanent document/photo/ID-card workflow.** The replacement adds printable ID cards and QR codes.

## New architecture

The replacement in this folder uses Flask + SQLite. The database is `school.db`; payments and attendance are relational records linked to students; login passwords are hashed; and admin-only actions are protected server-side.

