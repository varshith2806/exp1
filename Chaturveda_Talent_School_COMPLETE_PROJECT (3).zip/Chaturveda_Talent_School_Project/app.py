import os
import sqlite3
from datetime import date, datetime
from functools import wraps
from io import BytesIO
from pathlib import Path

from flask import Flask, flash, g, redirect, render_template, request, send_file, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "school.db"

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "change-this-secret-key-in-production")
app.config["SCHOOL_NAME"] = "CHATHURVEDA TALENT SCHOOL"
app.config["SCHOOL_LOCATION"] = "SURAMPALLY, TELANGANA"
app.config["SCHOOL_CODE"] = "CTS-SRM"
app.config["PRINCIPAL"] = "J. Shankar"

CLASS_ORDER = ["Nursery", "LKG", "UKG"] + [f"{i}th Class" if i not in (1,2,3) else {1:"1st Class",2:"2nd Class",3:"3rd Class"}[i] for i in range(1,11)]
SECTIONS = ["A", "B", "C", "D"]
ATTENDANCE_STATUSES = ["Present", "Absent", "Leave"]
PAYMENT_METHODS = ["Cash", "UPI", "Card"]

# Keep the original project's religion/caste terminology while moving storage to SQLite.
CASTE_DATA = {
    "Hindu": {
        "OC (Open Category)": ["Reddy", "Kamma", "Kapu", "Brahmin", "Arya Vysya", "Velama", "Kshatriya / Raju", "Rao", "Naidu", "Niyogi", "Deshastha", "Marwari", "Other OC"],
        "BC-A": ["Agnikulakshatriya / Palli / Vadabalija", "Boyer / Valmiki", "Gudala", "Gangaputra / Besta", "Jilakarra", "Kaikala / Sengundhar", "Kintala Kalinga", "Nayi-Brahmin / Mangala", "Rajaka / Chakali", "Vaddera", "Yata", "Other BC-A"],
        "BC-B": ["Dudekula / Pinjari", "Goud / Ediga", "Kummari / Shalivahana", "Kuruba / Kuruma", "Padmasali / Sali", "Perika", "Somavansha Kshatriya", "Swakulasali", "Viswabrahmin / Viswakarma", "Yadava / Golla", "Other BC-B"],
        "BC-C": ["Scheduled Caste Converts to Christianity", "Other BC-C"],
        "BC-D": ["Gawara", "Kandra", "Koppula Velama", "Munnuru Kapu", "Nagavaddilu", "Nayanavar", "Polinati Velama", "Srisayana / Senapathulu", "Surya Balija", "Turpu Kapu", "Vanikula Kshatriya", "Other BC-D"],
        "BC-E": ["Shaik / Sheikh", "Syed", "Pathan", "Attar Saibulu", "Dhobi Muslim", "Labbai", "Other BC-E"],
        "SC (Scheduled Caste)": ["Madiga", "Mala", "Adi Andhra", "Adi Dravida", "Arundhatiya", "Beda Jangam", "Bindla", "Chamar / Mochi", "Dandasi", "Dhor", "Dom / Domban", "Godagali", "Gosangi", "Jaggali", "Jambuvulu", "Mala Jangam", "Mang", "Matangi", "Mehtar", "Panchama", "Relli", "Samagara", "Samban", "Yatala", "Other SC Subcaste"],
        "ST (Scheduled Tribe)": ["Andh", "Bagata", "Bhil", "Chenchu", "Gadaba", "Gond", "Goudu", "Jatapu", "Koya", "Konda Dhora", "Konda Kapu", "Konda Reddi", "Kotia", "Savara", "Sugali / Lambada / Banjara", "Thoti", "Valmiki", "Yenadi", "Yerukula", "Other ST Subcaste"]
    },
    "Islam": {"General": ["Syed", "Sheikh", "Pathan", "Mughal", "Khan"], "BC-E": ["Shaik / Sheikh", "Syed", "Pathan", "Attar Saibulu", "Dhobi Muslim", "Labbai", "Garadi", "Fakir", "Other BC-E"]},
    "Christianity": {"General": ["Christian General"], "BC-C": ["Scheduled Caste Converts to Christianity", "Other BC-C"]},
    "Sikhism": {"General": ["Jat Sikh", "Ramgarhia", "Khatri Sikh", "Arora Sikh", "Other Sikh"]},
    "Buddhism": {"General": ["Neo-Buddhist", "Theravada", "Mahayana", "Other Buddhist"]},
    "Jainism": {"General": ["Digambara", "Svetambara", "Oswal", "Agarwal Jain", "Other Jain"]},
    "Other": {"General": ["General / Other"]}
}


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('admin','user')),
        full_name TEXT NOT NULL,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admission_no TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        dob TEXT NOT NULL,
        current_class TEXT NOT NULL,
        from_class TEXT,
        to_class TEXT,
        section TEXT NOT NULL,
        father TEXT,
        mother TEXT,
        phone TEXT,
        religion TEXT,
        caste TEXT,
        subcaste TEXT,
        nationality TEXT DEFAULT 'Indian',
        place_of_birth TEXT,
        admission_date TEXT NOT NULL,
        village TEXT,
        school_fee REAL NOT NULL DEFAULT 0,
        vehicle_required TEXT NOT NULL DEFAULT 'No',
        vehicle_fee REAL NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        receipt_no TEXT UNIQUE NOT NULL,
        student_id INTEGER NOT NULL,
        payment_date TEXT NOT NULL,
        method TEXT NOT NULL,
        school_amount REAL NOT NULL DEFAULT 0,
        vehicle_amount REAL NOT NULL DEFAULT 0,
        total_amount REAL NOT NULL DEFAULT 0,
        created_by INTEGER,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        attendance_date TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('Present','Absent','Leave')),
        remarks TEXT,
        marked_by INTEGER,
        UNIQUE(student_id, attendance_date),
        FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
        FOREIGN KEY(marked_by) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        channel TEXT NOT NULL,
        recipient TEXT NOT NULL,
        message TEXT NOT NULL,
        status TEXT NOT NULL,
        provider_sid TEXT,
        created_by INTEGER,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
    );
    """)
    admin = db.execute("SELECT id FROM users WHERE username='admin'").fetchone()
    if not admin:
        default_password = os.getenv("ADMIN_PASSWORD", "admin123")
        db.execute("INSERT INTO users(username,password_hash,role,full_name) VALUES(?,?,?,?)", ("admin", generate_password_hash(default_password), "admin", "School Administrator"))
    db.commit()
    db.close()


@app.before_request
def ensure_db():
    if not DB_PATH.exists():
        init_db()


@app.context_processor
def inject_globals():
    return {
        "school_name": app.config["SCHOOL_NAME"],
        "school_location": app.config["SCHOOL_LOCATION"],
        "school_code": app.config["SCHOOL_CODE"],
        "principal": app.config["PRINCIPAL"],
        "today": date.today().isoformat(),
        "current_user": current_user()
    }


def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    return get_db().execute("SELECT * FROM users WHERE id=? AND active=1", (uid,)).fetchone()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user():
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def role_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            user = current_user()
            if not user:
                return redirect(url_for("login", next=request.path))
            if user["role"] not in roles:
                flash("You do not have permission to perform that action.", "danger")
                return redirect(url_for("dashboard"))
            return view(*args, **kwargs)
        return wrapped
    return decorator


def clean(value):
    return (value or "").strip()


def money(value):
    return f"₹{float(value or 0):,.2f}"


def parse_amount(value):
    try:
        n = float(value or 0)
        if n < 0:
            raise ValueError
        return round(n, 2)
    except (ValueError, TypeError):
        raise ValueError("Amount must be a valid non-negative number.")


def next_admission_no():
    year = date.today().year
    prefix = f"CTS-{year}-"
    row = get_db().execute("SELECT admission_no FROM students WHERE admission_no LIKE ? ORDER BY id DESC LIMIT 1", (prefix + "%",)).fetchone()
    if not row:
        return prefix + "001"
    try:
        n = int(row["admission_no"].split("-")[-1]) + 1
    except ValueError:
        n = get_db().execute("SELECT COUNT(*) c FROM students").fetchone()["c"] + 1
    return prefix + str(n).zfill(3)


def receipt_no(payment_id=None):
    year = date.today().year
    if payment_id is None:
        row = get_db().execute("SELECT COALESCE(MAX(id),0)+1 n FROM payments").fetchone()
        payment_id = row["n"]
    return f"CTS-{year}-{int(payment_id):05d}"


def student_balances(student_id):
    db = get_db()
    student = db.execute("SELECT school_fee, vehicle_fee FROM students WHERE id=?", (student_id,)).fetchone()
    paid = db.execute("SELECT COALESCE(SUM(school_amount),0) school_paid, COALESCE(SUM(vehicle_amount),0) vehicle_paid FROM payments WHERE student_id=?", (student_id,)).fetchone()
    school_paid = float(paid["school_paid"])
    vehicle_paid = float(paid["vehicle_paid"])
    return {
        "school_paid": school_paid,
        "vehicle_paid": vehicle_paid,
        "school_due": max(float(student["school_fee"]) - school_paid, 0),
        "vehicle_due": max(float(student["vehicle_fee"]) - vehicle_paid, 0),
        "total_paid": school_paid + vehicle_paid,
        "total_due": max(float(student["school_fee"]) - school_paid, 0) + max(float(student["vehicle_fee"]) - vehicle_paid, 0)
    }


def enrich_student(row):
    item = dict(row)
    item.update(student_balances(row["id"]))
    return item


def number_to_words(num):
    n = int(round(float(num or 0)))
    if n == 0:
        return "Zero Rupees Only"
    ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"]
    tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]
    def two(x):
        if x < 20: return ones[x]
        return tens[x // 10] + (" " + ones[x % 10] if x % 10 else "")
    parts = []
    if n >= 10000000:
        parts += [two(n // 10000000), "Crore"]
        n %= 10000000
    if n >= 100000:
        parts += [two(n // 100000), "Lakh"]
        n %= 100000
    if n >= 1000:
        parts += [two(n // 1000), "Thousand"]
        n %= 1000
    if n >= 100:
        parts += [ones[n // 100], "Hundred"]
        n %= 100
    if n:
        if parts: parts.append("and")
        parts.append(two(n))
    return " ".join(parts) + " Rupees Only"


def date_to_words(value):
    if not value:
        return "N/A"
    try:
        d = datetime.strptime(value, "%Y-%m-%d")
        return d.strftime("%d %B %Y")
    except ValueError:
        return value


def academic_years(student):
    try:
        start = datetime.strptime(student["admission_date"], "%Y-%m-%d").year
    except Exception:
        start = date.today().year
    order = {name: i for i, name in enumerate(CLASS_ORDER)}
    a, b = order.get(student.get("from_class")), order.get(student.get("to_class"))
    years = (b - a + 1) if a is not None and b is not None and b >= a else 1
    return f"{start} – {start + years - 1}"


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user():
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = clean(request.form.get("username"))
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE username=? AND active=1", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            flash(f"Welcome, {user['full_name']}.", "success")
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("Invalid username or password.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))


@app.route("/")
@login_required
def dashboard():
    db = get_db()
    counts = {
        "students": db.execute("SELECT COUNT(*) c FROM students WHERE active=1").fetchone()["c"],
        "payments": db.execute("SELECT COUNT(*) c FROM payments").fetchone()["c"],
        "today_attendance": db.execute("SELECT COUNT(*) c FROM attendance WHERE attendance_date=?", (date.today().isoformat(),)).fetchone()["c"],
    }
    totals = db.execute("SELECT COALESCE(SUM(school_fee+vehicle_fee),0) total_fee FROM students WHERE active=1").fetchone()["total_fee"]
    paid = db.execute("SELECT COALESCE(SUM(school_amount+vehicle_amount),0) total_paid FROM payments").fetchone()["total_paid"]
    counts["total_fee"] = float(totals)
    counts["total_paid"] = float(paid)
    counts["total_due"] = max(counts["total_fee"] - counts["total_paid"], 0)
    recent = db.execute("""
        SELECT p.*, s.name, s.admission_no FROM payments p JOIN students s ON s.id=p.student_id
        ORDER BY p.id DESC LIMIT 8
    """).fetchall()
    return render_template("dashboard.html", counts=counts, recent=recent)


@app.route("/students")
@login_required
def students():
    db = get_db()
    q = clean(request.args.get("q"))
    if q:
        like = f"%{q}%"
        rows = db.execute("""SELECT * FROM students WHERE active=1 AND
            (name LIKE ? OR admission_no LIKE ? OR phone LIKE ? OR father LIKE ? OR village LIKE ? OR current_class LIKE ?)
            ORDER BY id DESC""", (like, like, like, like, like, like)).fetchall()
    else:
        rows = db.execute("SELECT * FROM students WHERE active=1 ORDER BY id DESC").fetchall()
    data = [enrich_student(r) for r in rows]
    return render_template("students.html", students=data, q=q)


@app.route("/students/new", methods=["GET", "POST"])
@login_required
def student_new():
    if request.method == "POST":
        return save_student(None)
    return render_template("student_form.html", student=None, balances=None, caste_data=CASTE_DATA, classes=CLASS_ORDER, sections=SECTIONS)


@app.route("/students/<int:student_id>/edit", methods=["GET", "POST"])
@login_required
def student_edit(student_id):
    db = get_db()
    row = db.execute("SELECT * FROM students WHERE id=? AND active=1", (student_id,)).fetchone()
    if not row:
        flash("Student not found.", "danger")
        return redirect(url_for("students"))
    if request.method == "POST":
        return save_student(student_id)
    return render_template("student_form.html", student=dict(row), balances=student_balances(student_id), caste_data=CASTE_DATA, classes=CLASS_ORDER, sections=SECTIONS)


def save_student(student_id):
    db = get_db()
    f = request.form
    try:
        name = clean(f.get("name")); dob = clean(f.get("dob")); current_class = clean(f.get("current_class")); section = clean(f.get("section"))
        admission_no = clean(f.get("admission_no")) or (db.execute("SELECT admission_no FROM students WHERE id=?", (student_id,)).fetchone()[0] if student_id else next_admission_no())
        if not name or not dob or not current_class or not section:
            raise ValueError("Student name, date of birth, class and section are required.")
        school_fee = parse_amount(f.get("school_fee")); vehicle_fee = parse_amount(f.get("vehicle_fee"))
        vehicle_required = clean(f.get("vehicle_required")) or "No"
        admission_date = clean(f.get("admission_date")) or date.today().isoformat()
        fields = (admission_no, name, dob, current_class, clean(f.get("from_class")) or current_class, clean(f.get("to_class")) or current_class,
                  section, clean(f.get("father")), clean(f.get("mother")), clean(f.get("phone")), clean(f.get("religion")), clean(f.get("caste")),
                  clean(f.get("subcaste")), clean(f.get("nationality")) or "Indian", clean(f.get("place_of_birth")), admission_date, clean(f.get("village")),
                  school_fee, vehicle_required, vehicle_fee)
        if student_id:
            db.execute("""UPDATE students SET admission_no=?,name=?,dob=?,current_class=?,from_class=?,to_class=?,section=?,father=?,mother=?,phone=?,religion=?,caste=?,subcaste=?,nationality=?,place_of_birth=?,admission_date=?,village=?,school_fee=?,vehicle_required=?,vehicle_fee=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""", fields + (student_id,))
            flash("Student details updated successfully.", "success")
        else:
            cur = db.execute("""INSERT INTO students(admission_no,name,dob,current_class,from_class,to_class,section,father,mother,phone,religion,caste,subcaste,nationality,place_of_birth,admission_date,village,school_fee,vehicle_required,vehicle_fee)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", fields)
            student_id = cur.lastrowid
            initial_school = parse_amount(f.get("initial_school_paid")); initial_vehicle = parse_amount(f.get("initial_vehicle_paid"))
            if initial_school > school_fee or initial_vehicle > vehicle_fee:
                raise ValueError("Initial payment cannot be greater than the corresponding fee.")
            if initial_school or initial_vehicle:
                cur = db.execute("INSERT INTO payments(receipt_no,student_id,payment_date,method,school_amount,vehicle_amount,total_amount,created_by) VALUES('PENDING',?,?,?,?,?,?,?)", (student_id, admission_date, clean(f.get("initial_payment_method")) or "Cash", initial_school, initial_vehicle, initial_school + initial_vehicle, current_user()["id"]))
                p_id = cur.lastrowid
                db.execute("UPDATE payments SET receipt_no=? WHERE id=?", (receipt_no(p_id), p_id))
            flash(f"Student registered successfully. Admission No: {admission_no}", "success")
        db.commit()
    except sqlite3.IntegrityError:
        db.rollback()
        flash("Admission/registration number already exists. Please use a unique number.", "danger")
        return redirect(request.url)
    except ValueError as e:
        db.rollback()
        flash(str(e), "danger")
        return redirect(request.url)
    return redirect(url_for("student_detail", student_id=student_id))


@app.route("/students/<int:student_id>")
@login_required
def student_detail(student_id):
    db = get_db()
    row = db.execute("SELECT * FROM students WHERE id=? AND active=1", (student_id,)).fetchone()
    if not row:
        flash("Student not found.", "danger")
        return redirect(url_for("students"))
    student = enrich_student(row)
    payments = db.execute("SELECT p.*, u.full_name FROM payments p LEFT JOIN users u ON u.id=p.created_by WHERE p.student_id=? ORDER BY p.id DESC", (student_id,)).fetchall()
    return render_template("student_detail.html", student=student, payments=payments, academic_years=academic_years(student))


@app.route("/students/<int:student_id>/delete", methods=["POST"])
@role_required("admin")
def student_delete(student_id):
    db = get_db()
    db.execute("UPDATE students SET active=0, updated_at=CURRENT_TIMESTAMP WHERE id=?", (student_id,))
    db.commit()
    flash("Student record archived. Payment and attendance history remains in the database.", "success")
    return redirect(url_for("students"))


@app.route("/students/<int:student_id>/payments", methods=["POST"])
@login_required
def add_payment(student_id):
    db = get_db()
    student = db.execute("SELECT * FROM students WHERE id=? AND active=1", (student_id,)).fetchone()
    if not student:
        flash("Student not found.", "danger")
        return redirect(url_for("students"))
    try:
        school_amount = parse_amount(request.form.get("school_amount")); vehicle_amount = parse_amount(request.form.get("vehicle_amount"))
        balances = student_balances(student_id)
        if school_amount > balances["school_due"] or vehicle_amount > balances["vehicle_due"]:
            raise ValueError("Payment cannot be greater than the remaining fee balance.")
        total = school_amount + vehicle_amount
        if total <= 0:
            raise ValueError("Enter a payment amount greater than zero.")
        method = clean(request.form.get("method")) or "Cash"
        if method not in PAYMENT_METHODS: raise ValueError("Invalid payment method.")
        payment_date = clean(request.form.get("payment_date")) or date.today().isoformat()
        cur = db.execute("INSERT INTO payments(receipt_no,student_id,payment_date,method,school_amount,vehicle_amount,total_amount,created_by) VALUES('PENDING',?,?,?,?,?,?,?)", (student_id, payment_date, method, school_amount, vehicle_amount, total, current_user()["id"]))
        pid = cur.lastrowid
        rno = receipt_no(pid)
        db.execute("UPDATE payments SET receipt_no=? WHERE id=?", (rno, pid))
        db.commit()
        flash(f"Payment saved. Receipt {rno} generated.", "success")
        return redirect(url_for("receipt", payment_id=pid))
    except ValueError as e:
        db.rollback(); flash(str(e), "danger")
        return redirect(url_for("student_detail", student_id=student_id))


@app.route("/payments/<int:payment_id>/receipt")
@login_required
def receipt(payment_id):
    db = get_db()
    p = db.execute("SELECT p.*, s.*, u.full_name AS created_by_name FROM payments p JOIN students s ON s.id=p.student_id LEFT JOIN users u ON u.id=p.created_by WHERE p.id=?", (payment_id,)).fetchone()
    if not p:
        flash("Receipt not found.", "danger")
        return redirect(url_for("students"))
    student = enrich_student(db.execute("SELECT * FROM students WHERE id=?", (p["student_id"],)).fetchone())
    prior = db.execute("SELECT COALESCE(SUM(school_amount),0) school, COALESCE(SUM(vehicle_amount),0) vehicle FROM payments WHERE student_id=? AND id < ?", (p["student_id"], payment_id)).fetchone()
    return render_template("receipt.html", payment=p, student=student, prior=prior, number_to_words=number_to_words)


@app.route("/students/<int:student_id>/bonafide")
@login_required
def bonafide(student_id):
    db=get_db(); row=db.execute("SELECT * FROM students WHERE id=?",(student_id,)).fetchone()
    if not row: return redirect(url_for("students"))
    student=enrich_student(row)
    return render_template("bonafide.html", student=student, academic_years=academic_years(student), date_to_words=date_to_words)


@app.route("/students/<int:student_id>/tc")
@login_required
def tc(student_id):
    db=get_db(); row=db.execute("SELECT * FROM students WHERE id=?",(student_id,)).fetchone()
    if not row: return redirect(url_for("students"))
    student=enrich_student(row)
    return render_template("tc.html", student=student, date_to_words=date_to_words)


@app.route("/students/<int:student_id>/id-card")
@login_required
def id_card(student_id):
    db=get_db(); row=db.execute("SELECT * FROM students WHERE id=?",(student_id,)).fetchone()
    if not row: return redirect(url_for("students"))
    student=enrich_student(row)
    qr_data = f"CTS|{student['admission_no']}|{student['name']}|{student['current_class']}|{student['section']}"
    qr_image = ""
    try:
        import qrcode
        import base64
        qr = qrcode.make(qr_data)
        buf = BytesIO(); qr.save(buf, format="PNG")
        qr_image = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()
    except Exception:
        qr_image = ""
    return render_template("id_card.html", student=student, qr_image=qr_image)


@app.route("/attendance", methods=["GET", "POST"])
@login_required
def attendance():
    db = get_db()
    selected_date = clean(request.values.get("attendance_date")) or date.today().isoformat()
    selected_class = clean(request.values.get("current_class"))
    selected_section = clean(request.values.get("section"))
    if request.method == "POST":
        student_ids = request.form.getlist("student_id")
        for sid in student_ids:
            status = request.form.get(f"status_{sid}", "Present")
            remarks = clean(request.form.get(f"remarks_{sid}"))
            db.execute("""INSERT INTO attendance(student_id,attendance_date,status,remarks,marked_by) VALUES(?,?,?,?,?)
                ON CONFLICT(student_id,attendance_date) DO UPDATE SET status=excluded.status, remarks=excluded.remarks, marked_by=excluded.marked_by""", (int(sid), selected_date, status, remarks, current_user()["id"]))
        db.commit()
        flash("Attendance saved successfully.", "success")
    rows=[]
    if selected_class and selected_section:
        rows=db.execute("""SELECT s.*, a.status, a.remarks FROM students s LEFT JOIN attendance a ON a.student_id=s.id AND a.attendance_date=?
            WHERE s.active=1 AND s.current_class=? AND s.section=? ORDER BY s.name""", (selected_date,selected_class,selected_section)).fetchall()
    return render_template("attendance.html", students=rows, classes=CLASS_ORDER, sections=SECTIONS, selected_date=selected_date, selected_class=selected_class, selected_section=selected_section, statuses=ATTENDANCE_STATUSES)


@app.route("/reports")
@login_required
def reports():
    db=get_db()
    class_filter=clean(request.args.get("current_class")); section=clean(request.args.get("section"))
    where="WHERE s.active=1"; params=[]
    if class_filter: where += " AND s.current_class=?"; params.append(class_filter)
    if section: where += " AND s.section=?"; params.append(section)
    students_rows=db.execute(f"SELECT s.* FROM students s {where} ORDER BY s.current_class,s.section,s.name",params).fetchall()
    total_fee=sum(float(r["school_fee"])+float(r["vehicle_fee"]) for r in students_rows)
    total_paid=db.execute(f"SELECT COALESCE(SUM(p.total_amount),0) x FROM payments p JOIN students s ON s.id=p.student_id {where}",params).fetchone()["x"]
    return render_template("reports.html", students=[enrich_student(r) for r in students_rows], total_fee=total_fee, total_paid=float(total_paid), total_due=max(total_fee-float(total_paid),0), classes=CLASS_ORDER, sections=SECTIONS, class_filter=class_filter, section=section)


@app.route("/reports/students.xlsx")
@login_required
def export_students_xlsx():
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font
    except ImportError:
        flash("Excel export needs openpyxl. Run: pip install -r requirements.txt", "danger")
        return redirect(url_for("reports"))
    rows=get_db().execute("SELECT * FROM students WHERE active=1 ORDER BY id").fetchall()
    wb=Workbook(); ws=wb.active; ws.title="Students"
    headers=["Admission No","Student Name","DOB","Class","Section","Father","Mother","Phone","Religion","Caste","Subcaste","Village","School Fee","School Paid","School Due","Vehicle","Vehicle Fee","Vehicle Paid","Vehicle Due","Admission Date"]
    ws.append(headers)
    for c in ws[1]: c.font=Font(bold=True)
    for r in rows:
        s=enrich_student(r); ws.append([s["admission_no"],s["name"],s["dob"],s["current_class"],s["section"],s["father"],s["mother"],s["phone"],s["religion"],s["caste"],s["subcaste"],s["village"],s["school_fee"],s["school_paid"],s["school_due"],s["vehicle_required"],s["vehicle_fee"],s["vehicle_paid"],s["vehicle_due"],s["admission_date"]])
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width=min(max(len(str(col[0].value or ""))+2,12),28)
    buf=BytesIO(); wb.save(buf); buf.seek(0)
    return send_file(buf,as_attachment=True,download_name=f"CTS_Students_{date.today().isoformat()}.xlsx",mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/reports/payments.xlsx")
@login_required
def export_payments_xlsx():
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font
    except ImportError:
        flash("Excel export needs openpyxl. Run: pip install -r requirements.txt", "danger")
        return redirect(url_for("reports"))
    rows=get_db().execute("SELECT p.*,s.admission_no,s.name FROM payments p JOIN students s ON s.id=p.student_id ORDER BY p.id DESC").fetchall()
    wb=Workbook(); ws=wb.active; ws.title="Payments"; headers=["Receipt No","Date","Admission No","Student","Method","School Amount","Vehicle Amount","Total","Created By"]
    ws.append(headers)
    for c in ws[1]: c.font=Font(bold=True)
    for r in rows: ws.append([r["receipt_no"],r["payment_date"],r["admission_no"],r["name"],r["method"],r["school_amount"],r["vehicle_amount"],r["total_amount"],r["created_by"]])
    buf=BytesIO(); wb.save(buf); buf.seek(0)
    return send_file(buf,as_attachment=True,download_name=f"CTS_Payments_{date.today().isoformat()}.xlsx",mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/reports/payments.pdf")
@login_required
def export_payments_pdf():
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    except ImportError:
        flash("PDF export needs reportlab. Run: pip install -r requirements.txt", "danger")
        return redirect(url_for("reports"))
    rows=get_db().execute("SELECT p.*,s.admission_no,s.name FROM payments p JOIN students s ON s.id=p.student_id ORDER BY p.id DESC").fetchall()
    buf=BytesIO(); doc=SimpleDocTemplate(buf,pagesize=landscape(A4),rightMargin=25,leftMargin=25,topMargin=25,bottomMargin=25)
    styles=getSampleStyleSheet(); story=[Paragraph(app.config["SCHOOL_NAME"],styles["Title"]),Paragraph("Payment Report",styles["Heading2"]),Spacer(1,10)]
    data=[["Receipt","Date","Adm No","Student","Mode","School","Vehicle","Total"]]
    for r in rows: data.append([r["receipt_no"],r["payment_date"],r["admission_no"],r["name"],r["method"],money(r["school_amount"]),money(r["vehicle_amount"]),money(r["total_amount"])])
    table=Table(data,repeatRows=1)
    table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#17365d")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),0.4,colors.grey),("FONTSIZE",(0,0),(-1,-1),8),("VALIGN",(0,0),(-1,-1),"MIDDLE")]))
    story.append(table); doc.build(story); buf.seek(0)
    return send_file(buf,as_attachment=True,download_name=f"CTS_Payments_{date.today().isoformat()}.pdf",mimetype="application/pdf")


@app.route("/change-password", methods=["GET", "POST"])
@login_required
def change_password():
    user = current_user()
    if request.method == "POST":
        old = request.form.get("old_password", "")
        new = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")
        if not check_password_hash(user["password_hash"], old):
            flash("Current password is incorrect.", "danger")
        elif len(new) < 6:
            flash("New password must contain at least 6 characters.", "danger")
        elif new != confirm:
            flash("New password and confirmation do not match.", "danger")
        else:
            db = get_db()
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new), user["id"]))
            db.commit()
            flash("Password changed successfully.", "success")
            return redirect(url_for("dashboard"))
    return render_template("change_password.html")


@app.route("/users", methods=["GET", "POST"])
@role_required("admin")
def users():
    db=get_db()
    if request.method=="POST":
        username=clean(request.form.get("username")); password=request.form.get("password",""); role=clean(request.form.get("role")); full_name=clean(request.form.get("full_name"))
        if not username or len(password)<6 or role not in ("admin","user") or not full_name:
            flash("Enter full name, username, role and a password of at least 6 characters.","danger")
        else:
            try:
                db.execute("INSERT INTO users(username,password_hash,role,full_name) VALUES(?,?,?,?)",(username,generate_password_hash(password),role,full_name)); db.commit(); flash("User created.","success")
            except sqlite3.IntegrityError: db.rollback(); flash("Username already exists.","danger")
    rows=db.execute("SELECT id,username,role,full_name,active,created_at FROM users ORDER BY id").fetchall()
    return render_template("users.html",users=rows)


@app.route("/users/<int:user_id>/toggle", methods=["POST"])
@role_required("admin")
def toggle_user(user_id):
    if user_id==current_user()["id"]:
        flash("You cannot deactivate your own account.","danger")
        return redirect(url_for("users"))
    db=get_db(); db.execute("UPDATE users SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?",(user_id,)); db.commit(); flash("User status updated.","success"); return redirect(url_for("users"))


@app.route("/students/<int:student_id>/notify/<channel>", methods=["POST"])
@login_required
def notify(student_id, channel):
    db=get_db(); s=db.execute("SELECT * FROM students WHERE id=? AND active=1",(student_id,)).fetchone()
    if not s: flash("Student not found.","danger"); return redirect(url_for("students"))
    balances=student_balances(student_id)
    message=(f"{app.config['SCHOOL_NAME']}: Fee reminder for {s['name']} ({s['admission_no']}). "
             f"School due {money(balances['school_due'])}, vehicle due {money(balances['vehicle_due'])}, total due {money(balances['total_due'])}.")
    phone=clean(s["phone"])
    if not phone:
        flash("This student has no parent phone number.","danger"); return redirect(url_for("student_detail",student_id=student_id))
    status="Failed"; provider_sid=""; error=""
    try:
        from twilio.rest import Client
        sid=os.getenv("TWILIO_ACCOUNT_SID"); token=os.getenv("TWILIO_AUTH_TOKEN")
        if not sid or not token: raise RuntimeError("Twilio credentials are not configured.")
        client=Client(sid,token)
        to = phone if phone.startswith("+") else "+91" + phone.lstrip("0")
        if channel=="sms":
            sender=os.getenv("TWILIO_SMS_FROM")
            if not sender: raise RuntimeError("TWILIO_SMS_FROM is not configured.")
            result=client.messages.create(body=message,from_=sender,to=to)
        elif channel=="whatsapp":
            sender=os.getenv("TWILIO_WHATSAPP_FROM","whatsapp:+14155238886")
            result=client.messages.create(body=message,from_=sender,to="whatsapp:"+to)
        else:
            raise RuntimeError("Unsupported notification channel.")
        status="Sent"; provider_sid=result.sid
        flash(f"{channel.upper()} notification sent.","success")
    except Exception as exc:
        error=str(exc); flash(f"Notification not sent: {error}","danger")
    db.execute("INSERT INTO notifications(student_id,channel,recipient,message,status,provider_sid,created_by) VALUES(?,?,?,?,?,?,?)",(student_id,channel,phone,message,status,provider_sid,current_user()["id"]))
    db.commit()
    return redirect(url_for("student_detail",student_id=student_id))


@app.template_filter("money")
def money_filter(v): return money(v)

@app.template_filter("date_in")
def date_in_filter(v):
    if not v: return ""
    try: return datetime.strptime(v,"%Y-%m-%d").strftime("%d-%m-%Y")
    except Exception: return v


if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=int(os.getenv("PORT","5000")), debug=os.getenv("FLASK_DEBUG","0")=="1")

