from pathlib import Path
from datetime import datetime
import shutil

BASE=Path(__file__).resolve().parent
DB=BASE/'school.db'
BACKUP_DIR=BASE/'backups'
BACKUP_DIR.mkdir(exist_ok=True)
if not DB.exists():
    raise SystemExit('school.db does not exist yet. Run app.py once first.')
out=BACKUP_DIR/f"school_{datetime.now():%Y%m%d_%H%M%S}.db"
shutil.copy2(DB,out)
print(f'Backup created: {out}')

