# CHATHURVEDA TALENT SCHOOL - Management System

A corrected replacement for the original single-page localStorage application.

## What changed

- Permanent SQLite database (`school.db`) instead of browser `localStorage`.
- Secure login with Admin/User roles and password hashing.
- Student registration/edit/search/archive.
- Fee collection with payment history and unique receipt numbers.
- Printable fee receipt, Bonafide/Conduct Certificate and Transfer Certificate.
- Printable student ID card with QR code.
- Daily attendance by class/section.
- Fee dashboard, due calculations and Excel/PDF exports.
- Admin account management.
- Optional SMS and WhatsApp reminders through Twilio; messages are sent only when an authorized user clicks the button.
- School logo included as `static/logo.png`.
- Database records survive closing the browser and restarting the application.

## Windows setup

Open Command Prompt or PowerShell inside this folder:

